# GZBlock — Privacy policy / Politique de confidentialité

_Last updated / Dernière mise à jour : 3 November 2026 / 3 novembre 2026_

## English

GZBlock does **not collect, store, sell or share any personal data**. It has no account,
no analytics, no telemetry and no server of its own.

**What stays on your device.** Your settings (language, blocking mode, privacy options),
the sites where you disabled GZBlock, the elements you chose to hide and the hidden-ads
and deleted-cookies counters are stored locally in your browser (`chrome.storage.local`).
They never leave your device.

**Network requests made by GZBlock.** Once a day, GZBlock downloads two public filter lists:
EasyList (`easylist.to`) and Liste FR (`easylist-downloads.adblockplus.org`). As with any
download, those servers can see your IP address. No personal data is sent with these requests.

**Why GZBlock reads web pages.** To hide ads, GZBlock looks at the structure of the pages
you visit, inside your browser only. Page content is never recorded or transmitted.

**Cookies and browser settings.** On your behalf, GZBlock removes advertising and tracking
cookies, sends ad-network requests without cookies, can send the Global Privacy Control
signal (`Sec-GPC: 1`), removes tracking parameters from links, and can block third-party
cookies and turn off the browser's ad-profiling features. All of these can be turned off in
the icon menu; turning an option off hands the setting back to the browser.

**Contact.** Open an issue on the project's GitHub repository.

## Français

GZBlock **ne collecte, ne stocke, ne vend et ne partage aucune donnée personnelle**. Il n'y a
ni compte, ni statistiques d'usage, ni télémétrie, ni serveur propre à GZBlock.

**Ce qui reste sur votre appareil.** Vos réglages (langue, mode de blocage, options de vie
privée), les sites où vous avez désactivé GZBlock, les éléments que vous avez masqués et les
compteurs (pubs masquées, cookies supprimés) sont enregistrés localement dans votre navigateur
(`chrome.storage.local`). Ils ne quittent jamais votre appareil.

**Requêtes réseau faites par GZBlock.** Une fois par jour, GZBlock télécharge deux listes de
filtres publiques : EasyList (`easylist.to`) et Liste FR (`easylist-downloads.adblockplus.org`).
Comme pour tout téléchargement, ces serveurs voient votre adresse IP. Aucune donnée personnelle
n'est envoyée avec ces requêtes.

**Pourquoi GZBlock lit les pages web.** Pour masquer les pubs, GZBlock analyse la structure des
pages que vous visitez, uniquement dans votre navigateur. Le contenu des pages n'est jamais
enregistré ni transmis.

**Cookies et réglages du navigateur.** Pour vous, GZBlock supprime les cookies publicitaires et
de pistage, envoie les requêtes des régies sans cookie, peut envoyer le signal Global Privacy
Control (`Sec-GPC: 1`), retire les paramètres de pistage des liens, et peut bloquer les cookies
tiers et désactiver le profilage publicitaire du navigateur. Tout cela se désactive depuis le
menu de l'icône ; désactiver une option rend le réglage au navigateur.

**Contact.** Ouvrez une « issue » sur le dépôt GitHub du projet.
